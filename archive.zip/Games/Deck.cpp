#include "Deck.h"

random_device rd;

Deck::Deck() {
    card tempCard;
    for (int s = 0; s < 4; s++) {
        tempCard.suit = SUITS[s];
        for (int f = 2; f <= 14; f++) {
            tempCard.faceNum = f;
            deckOfCards.push_back(tempCard);
        }
    }
}

void Deck::shuffle() {
    std::shuffle(deckOfCards.begin(), deckOfCards.end(), rd);
}

void Deck::print() {
    for (card _card : deckOfCards) {
        printCard(_card);
        cout << endl;
    }
}

void Deck::deal(int cardsToDeal, WarHand& playerHand, WarHand& compHand)
{
    for (int i = 0; i < cardsToDeal / 2; i++)
    {
        playerHand.addCard(deckOfCards.back());
        deckOfCards.pop_back();
        compHand.addCard(deckOfCards.back());
        deckOfCards.pop_back();
    }
}
/*void Deck::deal(int cardsToDeal, BJ_Hand& playerHand, BJ_Hand& compHand)
{
    for (int i = 0; i < cardsToDeal / 2; i++)
    {
        playerHand.addCard(deckOfCards.back());
        deckOfCards.pop_back();
        compHand.addCard(deckOfCards.back());
        deckOfCards.pop_back();
    }
}*/